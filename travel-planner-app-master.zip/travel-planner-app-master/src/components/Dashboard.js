import React from 'react';

const Dashboard = () => {
    return <h1>Welcome to the Dashboard!</h1>;
};

export default Dashboard;
