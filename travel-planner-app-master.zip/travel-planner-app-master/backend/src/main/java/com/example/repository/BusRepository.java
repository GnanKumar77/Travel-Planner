package com.example.repository;

import com.example.entity.Bus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BusRepository extends JpaRepository<Bus, Long> {
    // No need to declare custom methods unless needed
}
