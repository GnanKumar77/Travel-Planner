package com.example.entity;

public enum BookingType {
    CAB,
    HOTEL,
    FLIGHT,
    TRAIN,
    BUS
}
